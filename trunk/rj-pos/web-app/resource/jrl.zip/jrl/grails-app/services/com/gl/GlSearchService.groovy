package com.gl
import groovy.sql.Sql
import com.app.*

class GlSearchService {

    static transactional = true

    def dataSource

    def serviceMethod() {

    }
    
    def getGlAccounts(String glAccount, String description, def type, GlAccount parent) {
        String newGlAccount = "%%"
        String newDescription = "%%"
        
        if(glAccount){
            newGlAccount = "%" + glAccount + "%"
        }
        if(description){
            newDescription = "%" + description + "%"
        }

        
        def result = GlAccount.executeQuery("\
            FROM GlAccount gl\
            WHERE (gl.glAccount LIKE ?\
            AND gl.description LIKE ?)", [newGlAccount, newDescription]
        )

        if(type!=null && parent!=null){
            result = GlAccount.executeQuery("\
                FROM GlAccount gl\
                WHERE (gl.glAccount LIKE ?\
                AND gl.description LIKE ?)\
                AND gl.glAccountType = ?\
                AND gl.parentGlAccount = ?", [newGlAccount, newDescription, type, parent]
            )
        }
        if(type!=null && parent==null){
            result = GlAccount.executeQuery("\
                FROM GlAccount gl\
                WHERE (gl.glAccount LIKE ?\
                AND gl.description LIKE ?)\
                AND gl.glAccountType = ?", [newGlAccount, newDescription, type]
            )
        }
        if(type==null && parent!=null){
            result = GlAccount.executeQuery("\
                FROM GlAccount gl\
                WHERE (gl.glAccount LIKE ?\
                AND gl.description LIKE ?)\
                AND gl.parentGlAccount = ?", [newGlAccount, newDescription, parent]
            )
        }

        return result
    }

     def getGlAccountTypes(String glAccountType, String description, String glAccountClass) {
        String newGlAccountType = "%%"
        String newDescription = "%%"

        if(glAccountType){
            newGlAccountType = "%" + glAccountType + "%"
        }
        if(description){
            newDescription = "%" + description + "%"
        }


        def result = GlAccountType.executeQuery("\
            FROM GlAccountType glType\
            WHERE (glType.glAccountType LIKE ?\
            AND glType.description LIKE ?)", [newGlAccountType, newDescription]
        )

        if(glAccountClass){
            result = GlAccountType.executeQuery("\
                FROM GlAccountType glType\
                WHERE (glType.glAccountType LIKE ?\
                AND glType.description LIKE ?\
                AND glAccountClass = ?)", [newGlAccountType, newDescription, glAccountClass])
        }

        return result
    }

    def getAcctgPeriod(AppOrganization organization, PeriodType periodType, String acctgPeriod, Integer periodNum, String status, def year) {
        String newAcctgPeriod = "%%"
        
        if(acctgPeriod){
            newAcctgPeriod = "%" + acctgPeriod + "%"
        }

        def result = AcctgPeriod.executeQuery("\
            FROM AcctgPeriod acctgPeriod\
            WHERE (acctgPeriod.acctgPeriod LIKE ?\
            AND acctgPeriod.organization = ?)", [newAcctgPeriod, organization]
        )
        if(status!=null || year!=null){
            if(status=='null' && year!='null'){
                result = AcctgPeriod.executeQuery("\
                    FROM AcctgPeriod acctgPeriod\
                    WHERE (acctgPeriod.acctgPeriod LIKE ?\
                    AND acctgPeriod.organization = ?)\
                    AND acctgPeriod.year = ?", [newAcctgPeriod, organization, year])
            } else if(status!='null' && year=='null'){
                result = AcctgPeriod.executeQuery("\
                    FROM AcctgPeriod acctgPeriod\
                    WHERE (acctgPeriod.acctgPeriod LIKE ?\
                    AND acctgPeriod.organization = ?)\
                    AND acctgPeriod.status = ?)", [newAcctgPeriod, organization, status])
            } else if(status!='null' && year!='null'){
                result = AcctgPeriod.executeQuery("\
                    FROM AcctgPeriod acctgPeriod\
                    WHERE (acctgPeriod.acctgPeriod LIKE ?\
                    AND acctgPeriod.organization = ?)\
                    AND acctgPeriod.status = ?\
                    AND acctgPeriod.year = ?", [newAcctgPeriod, organization, status, year])
            }
        }
        return result
    }
}
