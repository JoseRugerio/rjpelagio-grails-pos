package com.app

class ApprovalSeq {

    Integer sequence
    String remarks

    static constraints = {
        remarks (inList: ['Noted By', 'Approved By', 'Reviewed By'])
    }
}
