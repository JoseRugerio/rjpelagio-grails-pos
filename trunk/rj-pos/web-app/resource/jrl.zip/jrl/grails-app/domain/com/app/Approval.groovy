package com.app

class Approval {

    String description
    String department
    String approvalFeature

    static constraints = {
        description (blank: false)
        department (blank: false)
        approvalFeature (inList : ['Voucher Approval', 'Leave'])
    }
}
