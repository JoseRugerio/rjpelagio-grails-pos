package com.gl

class AcctgTransType {
    String acctgTransTypeId
    String acctgTransName

    //static mapping = {
    //    id column : "acctg_trans_type_id", type : "string"
    //}
    
    static constraints = {
        acctgTransTypeId (blank : false)
        acctgTransName (blank : false)
    }
}
