package com.gl

import com.app.AppOrganization

class AcctgPeriod {
        String acctgPeriod
        Integer acctgPeriodNum
        Date fromDate
        String status = 'Open'
        String year
        Date thruDate
        Date dateCreated

    

    static belongsTo = [periodTypeId : PeriodType,
                       organization : AppOrganization]
    
    static constraints = {
        acctgPeriod (blank : false)
        acctgPeriodNum (blank : false)
        fromDate (blank : false)
        status (blank : true, inList: ['Open', 'Close'])
        thruDate (blank : false)
        year (blank : true)
        dateCreated()
    }
    String toString() {
        return "${acctgPeriod}"
    }

}
