package com.gl

import grails.converters.deep.JSON
import groovy.sql.Sql
import com.app.*

class GlAccountingTransactionController {

    static allowedMethods = [save: "POST", update: "POST", delete: "POST"]
    
    def beforeInterceptor = [action:this.&auth]
    
    def glSearchService;
    def glAcctgTransactionService;

    def dataSource;

    def auth() {
        if(!session.user) {
            redirect(uri:"/")
            return false
        }
    }

    def index = {
        redirect(action: "list", params: params)
    }

    def list = {
        params.max = Math.min(params.max ? params.int('max') : 10, 100)
        def glAccountingTransactionInstance = new GlAccountingTransaction()
        def offset = 0
        if(params.offset==null){
            offset = 0 + params.int('max')
        }
        else{
            offset = params.int('offset') + params.int('max')
        }
        if(offset > GlAccountingTransaction.count()){
            offset = GlAccountingTransaction.count()
        }
        [glAccountingTransactionInstanceList: GlAccountingTransaction.list(params), glAccountingTransactionInstanceTotal: GlAccountingTransaction.count(), glAccountingTransactionInstance: glAccountingTransactionInstance, recordCount : offset]
    }

    def create = {
        def glAccountingTransactionInstance = new GlAccountingTransaction()
        glAccountingTransactionInstance.properties = params
        def glAccounts = [:];
        def glAccountList = [:];
        def debit = 0.00;
        def credit = 0.00;
        
        //Initialize lookup results 
        params.max = Math.min(params.max ? params.int('max') : 10, 100)
        def glAccountInstanceList = [:]
        def glAccountInstanceTotal = 0
        //End
        
        glAccountList = GlAccountOrganization.executeQuery("\
            FROM GlAccountOrganization org\
            WHERE org.organization = ?\
            ", [session.organization]);
        return [glAccountingTransactionInstance: glAccountingTransactionInstance, 
            glAccountList : glAccountList, 
            glAccounts : glAccounts,
            debit : debit,
            credit : credit,
            glAccountInstanceList : glAccountInstanceList,
            glAccountInstanceTotal : glAccountInstanceTotal]
    }

    def save = {
        def glAccountingTransactionInstance = new GlAccountingTransaction(params);
        glAccountingTransactionInstance.organization = session.organization;
        glAccountingTransactionInstance.entryDate = new Date()
        glAccountingTransactionInstance.party = Party.get(params.partyId)
        glAccountingTransactionInstance.status = "Active"
        //flash.message = "${params.glAccounts}, ${params.amounts}, ${params.debitCreditFlags}";
        
        //Parameters
        def glAccounts = params.glAccounts;
        def debits = params.debits;
        def credits = params.credits;
        def debit = params.debit;
        def credit = params.credit;
        System.out.println("Debits : " + debits);
        System.out.println("Credits : " + credits);
        if(debit != credit) {
            //GL Account List
            def glAccountList = [:];
            glAccountList = GlAccountOrganization.executeQuery("\
                FROM GlAccountOrganization org\
                WHERE org.organization LIKE ?\
                ", [session.organization]);
            
            flash.message = "Debit and Credit values are not equal.";
            
            render(view: "create", model: [glAccountingTransactionInstance: glAccountingTransactionInstance, 
                glAccountList : glAccountList, 
                glAccounts : glAccounts,
                debits : debits,
                credits : credits,
                debit : debit,
                credit : credit]
            )
        } else {
            glAccountingTransactionInstance.entryDate = glAccountingTransactionInstance.transactionDate;
            glAccountingTransactionInstance.status = "Active"
            glAccountingTransactionInstance.save()
            if (glAccountingTransactionInstance.hasErrors()) {
                //GL Account List
                def glAccountList = [:];
                glAccountList = GlAccountOrganization.executeQuery("\
                    FROM GlAccountOrganization org\
                    WHERE org.organization LIKE ?\
                    ", [session.organization]);
                
                render(view: "create", model: [glAccountingTransactionInstance: glAccountingTransactionInstance, 
                glAccountList : glAccountList, 
                glAccounts : glAccounts,
                debits : debits,
                credits : credits,
                debit : debit,
                credit : credit])
            } else {
            
                //Data Entry
                glAcctgTransactionService.insertAcctgTrans(
                    glAccountingTransactionInstance,
                    glAccounts,
                    debits,
                    credits
                )
                
                flash.message = "${message(code: 'default.created.message', args: [message(code: 'glAccountingTransaction.label', default: 'GlAccountingTransaction'), glAccountingTransactionInstance.id])}"
                redirect(action: "show", id: glAccountingTransactionInstance.id)
            }
            
        }
    }

    def show = {
        def glAccountingTransactionInstance = GlAccountingTransaction.get(params.id)
        if (!glAccountingTransactionInstance) {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'glAccountingTransaction.label', default: 'GlAccountingTransaction'), params.id])}"
            redirect(action: "list")
        }
        else {
            //retrieve acctg trans items
            def transItems = GlAccountingTransactionDetails.findAllByGlAccountingTransaction(glAccountingTransactionInstance);
            [glAccountingTransactionInstance: glAccountingTransactionInstance, transItems : transItems]
        }
    }

    def edit = {
        def glAccountingTransactionInstance = GlAccountingTransaction.get(params.id)
        if (!glAccountingTransactionInstance) {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'glAccountingTransaction.label', default: 'GlAccountingTransaction'), params.id])}"
            redirect(action: "list")
        }
        else {
            def transItems = GlAccountingTransactionDetails.findAllByGlAccountingTransaction(glAccountingTransactionInstance);
            def glAccounts = [];
            def debits = [];
            def credits = [];
            def credit = 0;
            def debit = 0;
            for(int i = 0; i < transItems.size(); i++){
                def acctOrg = GlAccountOrganization.findByGlAccountAndOrganization(transItems[i].glAccount, session.organization);
                glAccounts.add(acctOrg.id);
                if (transItems[i].debitCreditFlag.equalsIgnoreCase("Debit")){
                    debits.add(transItems[i].amount);
                    debit = debit + transItems[i].amount
                    credits.add(0)
                } else if (transItems[i].debitCreditFlag.equalsIgnoreCase("Credit")){
                    debits.add(0);
                    credits.add(transItems[i].amount)
                    credit = credit + transItems[i].amount
                }
            }

            def glAccountList = [:];
            def glAccountItems = [];
            def amounts = [];
            def debitCreditFlags = [];
            glAccountList = GlAccountOrganization.executeQuery("\
                FROM GlAccountOrganization org\
                WHERE org.organization LIKE ?\
                ", [session.organization]);            
            [glAccountingTransactionInstance: glAccountingTransactionInstance, 
                transItems : transItems,
                glAccountList : glAccountList,
                glAccounts : glAccounts,
                glAccountItems : glAccountItems,
                debits : debits,
                credits : credits,
                debit : debit,
                credit : credit
                ]
        }
    }

    def update = {
        def glAccountingTransactionInstance = GlAccountingTransaction.get(params.id)
        def glAccountItems = params.glAccounts;
        def debits = params.debits;
        def credits = params.credits;
        def debit = params.debit;
        def credit = params.credit;
        def glAccountList = [:];
        def transItems = [:];
        glAccountList = GlAccountOrganization.executeQuery("\
            FROM GlAccountOrganization org\
            WHERE org.organization LIKE ?\
            ", [session.organization]); 
        
        if (glAccountingTransactionInstance) {
            if (params.debit != params.credit) {
                
                flash.message = "Debit and Credit values are not equal.";
                render(view: "edit", model: [glAccountingTransactionInstance: glAccountingTransactionInstance, 
                    glAccountList : glAccountList, 
                    glAccountItems : glAccountItems,
                    debits : debits,
                    credits : credits,
                    debit : params.debit,
                    credit : params.credit,
                    transItems : transItems])
            
            } else {
                if (params.version) {
                    def version = params.version.toLong()
                    if (glAccountingTransactionInstance.version > version) {

                        glAccountingTransactionInstance.errors.rejectValue("version", "default.optimistic.locking.failure", [message(code: 'glAccountingTransaction.label', default: 'GlAccountingTransaction')] as Object[], "Another user has updated this GlAccountingTransaction while you were editing")
                        render(view: "edit", model: [glAccountingTransactionInstance: glAccountingTransactionInstance, 
                            glAccountList : glAccountList, 
                            glAccountItems : glAccountItems,
                            credits : credits,
                            debits : debits,
                            debit : params.debit,
                            credit : params.credit,
                            transItems : transItems])
                        return
                    }
                }
                //Do the updating
                glAccountingTransactionInstance.properties = params
                glAcctgTransactionService.updateAcctgTrans(
                    glAccountingTransactionInstance,
                    glAccountItems,
                    debits,
                    credits
                )
                
                flash.message = "${message(code: 'default.updated.message', args: [message(code: 'glAccountingTransaction.label', default: 'GlAccountingTransaction'), glAccountingTransactionInstance.id])}"
                redirect(action: "show", id: glAccountingTransactionInstance.id)
            }
        } else {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'glAccountingTransaction.label', default: 'GlAccountingTransaction'), params.id])}"
            redirect(action: "list")
        }
    }

    def delete = {
        def glAccountingTransactionInstance = GlAccountingTransaction.get(params.id)
        if (glAccountingTransactionInstance) {
            try {
                glAccountingTransactionInstance.delete(flush: true)
                flash.message = "${message(code: 'default.deleted.message', args: [message(code: 'glAccountingTransaction.label', default: 'GlAccountingTransaction'), params.id])}"
                redirect(action: "list")
            }
            catch (org.springframework.dao.DataIntegrityViolationException e) {
                flash.message = "${message(code: 'default.not.deleted.message', args: [message(code: 'glAccountingTransaction.label', default: 'GlAccountingTransaction'), params.id])}"
                redirect(action: "show", id: params.id)
            }
        }
        else {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'glAccountingTransaction.label', default: 'GlAccountingTransaction'), params.id])}"
            redirect(action: "list")
        }
    }
    
    def lookupSearchAction = {
        params.max = Math.min(params.max ? params.int('max') : 10, 100)
        params.description = "Cash"
        def gl = new GlAccount();
        gl.properties = params.properties;
        def glAccountInstanceList = glSearchService.getGlAccounts(
            gl.glAccount, gl.description, gl.glAccountType
        );
        def glAccountInstanceTotal = glAccountList.size();
        glAccountInstanceList = GlAccount.list(params);
        
        redirect(action: "create", model:[glAccountList : glAccountList, glAccountInstanceTotal : glAccountInstanceTotal])
        render glAccountList as JSON
        
    }

    def consol = {
        def orgId = session.organization.id
        
        def dropDown = AcctgPeriod.executeQuery("\
            FROM AcctgPeriod ap\
            WHERE ap.status = ?\
            AND ap.organization = ?\
            ORDER BY ap.fromDate", ["Open", session.organization]
        )

        def currentPeriod = com.gl.AcctgPeriod.executeQuery("\
            FROM AcctgPeriod ap\
            WHERE status = ?\
            ORDER BY fromDate", ["Open"])

        def currentPeriodInstance = currentPeriod[0].id

        if(params.acctgPeriod) {
            currentPeriodInstance = Integer.parseInt(params.acctgPeriod)
            println "Pumasok Controller Param: " + params.acctgPeriod
        }
        
        println "Controller Instance: " + currentPeriodInstance
        
        params.max = Math.min(params.max ? params.int('max') : 10, 100)
        def result = glAcctgTransactionService.consolResult(currentPeriodInstance, orgId)
        
        [glAcctConsolInstanceList: result.asList() , glAcctConsolInstanceTotal: result.size(), dropDown : dropDown, currentPeriodInstance : currentPeriodInstance]
    }

    def process = {
        def orgId = session.organization.id
        def currentPeriodInstance = Integer.parseInt(params.id)
        //To check if all previous periods are consolidated.
        def checkPrevConsol = AcctgPeriod.executeQuery("\
            FROM AcctgPeriod ap\
            WHERE ap.status = ?\
            AND ap.thruDate <= ?\
            AND ap.organization = ?\
            ORDER BY fromDate", ["Open", new Date(), session.organization]
        )
        if(checkPrevConsol.size()<=0) {
            //All previous period are consolidated.
            def result = glAcctgTransactionService.processConsol(currentPeriodInstance, orgId);
            def sizeResult = checkPrevConsol.size()
            def countResult = checkPrevConsol.count()
            flash.message = "${message(code: 'glAccountingTransConsolidation.consolidated', args: [message(code: 'glAccountingTransConsolidation.label', default: 'GlAccountingTransactionConsolidation'), currentPeriodInstance])}"
        }
        else{
            //There are previous period that needs consolidation
            flash.message = "${message(code: 'glAccountingTransConsolidation.error', args: [message(code: 'glAccountingTransConsolidation.label', default: 'GlAccountingTransactionConsolidation'), currentPeriodInstance])}"
            println ("Needs Consolidation")
        }
        
        redirect(action: "consol")
    }
}
