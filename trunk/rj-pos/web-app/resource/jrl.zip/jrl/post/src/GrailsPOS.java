public class GrailsPOS {

}
