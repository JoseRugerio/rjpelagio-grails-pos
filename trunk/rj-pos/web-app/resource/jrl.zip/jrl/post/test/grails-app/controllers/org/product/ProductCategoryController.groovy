package org.product

class ProductCategoryController {
    static scaffold = true
}
