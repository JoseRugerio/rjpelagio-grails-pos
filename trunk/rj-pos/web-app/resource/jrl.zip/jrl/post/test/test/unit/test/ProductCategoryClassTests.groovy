package test



import grails.test.mixin.*
import org.junit.*
import org.product.ProductCategoryClass;

/**
 * See the API for {@link grails.test.mixin.domain.DomainClassUnitTestMixin} for usage instructions
 */
@TestFor(ProductCategoryClass)
class ProductCategoryClassTests {

    void testSomething() {
       fail "Implement me"
    }
}
