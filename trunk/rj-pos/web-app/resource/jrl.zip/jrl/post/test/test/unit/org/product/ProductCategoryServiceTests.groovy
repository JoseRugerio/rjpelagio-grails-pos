package org.product



import grails.test.mixin.*
import org.junit.*

/**
 * See the API for {@link grails.test.mixin.services.ServiceUnitTestMixin} for usage instructions
 */
@TestFor(ProductCategoryService)
class ProductCategoryServiceTests {

    void testSomething() {
        fail "Implement me"
    }
}
