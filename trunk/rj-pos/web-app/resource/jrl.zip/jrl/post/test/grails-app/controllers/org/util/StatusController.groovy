package org.util

class StatusController {
    static scaffold = true
}
