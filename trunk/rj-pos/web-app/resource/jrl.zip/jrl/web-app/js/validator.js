/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * Validator functions
 */
/* Removes non numeric digits on text fields */
function validateInteger(value) 
{ 
    value = value.replace(/[^0-9.]/g, '');
    value = Math.floor(value * 100) / 100
    return value;
}
